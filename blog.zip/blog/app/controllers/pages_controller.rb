class PagesController < ApplicationController
  def home
  	@les_articles = Article.all
  end

  def show
  	@le_article = Article.find(params[:id])	
  end
end
